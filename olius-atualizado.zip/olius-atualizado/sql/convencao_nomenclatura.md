# Convenção de nomenclatura do banco Olius

Documento pedido em Banco de Dados 1 (extra). Vale para o PostgreSQL do projeto.

## Regras

| Item | Regra | Exemplo |
|---|---|---|
| Tabelas e colunas | minúsculas, `snake_case`, **sem aspas** | `solicitacao_coleta`, `dt_emissao` |
| Nome da tabela | singular, nome do que ela guarda | `usuario`, `motorista`, `coleta` |
| Chave primária | `id_` + nome da tabela, tipo `SERIAL` | `id_usuario`, `id_coleta` |
| Chave estrangeira | **mesmo nome** da chave primária que referencia | `coleta.id_motorista` → `motorista.id_motorista` |
| Datas | prefixo `dt_`, tipo `DATE` | `dt_entrega`, `dt_solicitacao` |
| Quantidades em litros | prefixo `volume_`, `DECIMAL(10,2)` | `volume_coletado` |
| Restrições nomeadas | `chk_` + tabela + regra | `chk_carteira_um_dono` |
| Valores fixos (antes ENUM) | `CHECK (coluna IN (...))` | `status IN ('Pendente','Realizada','Cancelada')` |
| Senhas | só o **hash PBKDF2**, nunca a senha digitada | `pbkdf2$120000$sal$hash` |

## Por que sem aspas

No PostgreSQL, `"USUARIO"` (com aspas) e `usuario` são nomes diferentes. Com aspas o
nome fica preso às maiúsculas e todo comando SQL do Java precisaria repetir as aspas.
Sem aspas o banco guarda tudo em minúsculas e o Java escreve `FROM usuario` normalmente.

## Por que CHECK em vez de ENUM

O JDBC envia texto (`setString`). Uma coluna `ENUM` do PostgreSQL recusa texto sem
conversão (`column "x" is of type ... but expression is of type character varying`).
Com `VARCHAR + CHECK` o mesmo comando funciona e o banco continua barrando valores inválidos.

## DEFAULTs usados

`primeiro_registro`, `dt_solicitacao`, `dt_entrega`, `dt_coleta`, `dt_emissao`,
`dt_aprovacao` = data de hoje · `em_ativo` = `Ativo` · `status` do motorista = `Disponivel`
· `status` do PEV e da solicitação = `Pendente` · `plano` = `Basico` ·
`patente` = `Bronze` · `nivel` = 1 · `pontos_totais` = 0.
