# Olius – atualização (SQL sem aspas, login do ADM, site limpo)

## 1. Banco de dados

Rode no banco do projeto, **nesta ordem**:

1. `sql/01_esquema.sql` – apaga e recria as tabelas (sem aspas, com DEFAULT e CHECK)
2. `sql/02_dataload.sql` – carga inicial de teste (12 usuários, 2 administradores etc.)

> O `01` apaga as tabelas existentes. Faça backup antes se houver dados importantes.

Convenção de nomes: `sql/convencao_nomenclatura.md`.

## 2. Código (IntelliJ)

A pasta `main/` tem o mesmo formato de `src/main` do seu projeto: copie por cima, mantendo as
pastas. Depois **apague** os arquivos listados em `APAGAR.txt` (não existem mais no novo banco ou
foram trocados pelo login do administrador).

Nada muda nas variáveis de ambiente: `DB_URL`, `DB_USERNAME` e `DB_PASSWORD`, como antes.

## 3. Login do administrador

- No site, o link **Acesso ADM** (rodapé) abre `/login-adm`. A logo do cabeçalho volta para a página inicial.
- Login correto leva direto ao CRUD (`/adm/index.jsp`).
- Só entra quem tem registro **ativo** na tabela `adm` e acerta a senha.
- Dados de teste (do `02_dataload.sql`):

| E-mail | Senha | Situação |
|---|---|---|
| `admin@olius.local` | `senha_teste_123` | Ativo, entra no painel |
| `inativo@olius.local` | `senha_teste_123` | Desativado, é barrado com aviso |

- O painel `/adm/*` e as APIs do CRUD (`/usuarios`, `/b2b`, `/pevs` etc.) ficam bloqueados para
  quem não está logado (`AdmFiltro`). Sessão expira em 30 minutos sem uso.
- Para sair: `/login-adm?sair=1`.

### Criar outro administrador

Rode `Organizacao.Utilitarios.SenhaUtil` passando a senha como argumento (no IntelliJ: *Run →
Edit Configurations → Program arguments*). Ele imprime o hash; cole no `INSERT`:

```sql
INSERT INTO adm (nome, email, senha, em_ativo)
VALUES ('Seu Nome', 'seu@email.com', '<hash gerado>', 'Ativo');
```

Com um administrador logado também dá para cadastrar pela API `POST /adms`
(parâmetros `nome`, `email`, `senha`, `em_ativo`); a senha é salva já como hash.

## 4. O que mudou

**Site:** removidos o botão "Sair" e o borrão amarelo (`.luz-amarela`); a
logo do cabeçalho agora leva ao login do administrador; o site abre em `index.jsp`.

**Banco ↔ Java:** `CarteiraDAO`, `EntregaPevDAO`, `PontosMovimentacaoDAO` e `B2cDAO` (com seus
models e servlets) foram refeitos para as colunas reais do banco. `PontuacaoDAO` e
`ParticipacaoEventoDAO` usavam tabelas que não existem e saíram. `TipoUsuario` agora é
`B2B, B2C, PEV`, igual ao banco.

**Requisitos do 1º ano atendidos:** script SQL com DEFAULT e CHECK, DataLoad, convenção de
nomenclatura (BD1); comentários, tratamento de exceções e validação com REGEX de CPF e telefone
(Lógica / SO); pacotes `servlet`, `dao`, `model`, JDBC com Postgres e CRUD web (POO / Dev 1).
