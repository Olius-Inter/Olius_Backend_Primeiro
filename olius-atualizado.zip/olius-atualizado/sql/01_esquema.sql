-- ============================================================
-- BANCO DE DADOS OLIUS - PostgreSQL
-- Script 01: ESTRUTURA (tabelas, chaves, DEFAULTs e CHECKs)
--
-- ATENCAO: este script APAGA as tabelas existentes antes de recria-las.
-- Faca backup antes de executar em um banco que contenha dados importantes.
-- Ordem de execucao: 01_esquema.sql  ->  02_dataload.sql
--
-- Nomes sem aspas: tabelas e colunas em minusculas com underscore
-- (veja convencao_nomenclatura.md).
-- ============================================================

BEGIN;

-- ------------------------------------------------------------
-- Limpeza: tabelas na ordem inversa das dependencias
-- ------------------------------------------------------------
DROP TABLE IF EXISTS movimentacao_pontos CASCADE;
DROP TABLE IF EXISTS certificado CASCADE;
DROP TABLE IF EXISTS entrega_pev CASCADE;
DROP TABLE IF EXISTS coleta CASCADE;
DROP TABLE IF EXISTS solicitacao_coleta CASCADE;
DROP TABLE IF EXISTS atualizacao CASCADE;
DROP TABLE IF EXISTS carteira CASCADE;
DROP TABLE IF EXISTS pev CASCADE;
DROP TABLE IF EXISTS b2c CASCADE;
DROP TABLE IF EXISTS b2b CASCADE;
DROP TABLE IF EXISTS motorista CASCADE;
DROP TABLE IF EXISTS adm CASCADE;
DROP TABLE IF EXISTS usuario CASCADE;
DROP TABLE IF EXISTS endereco CASCADE;

-- Tipos ENUM das versoes antigas do banco (agora usamos CHECK, que
-- funciona direto com setString do JDBC, sem cast)
DROP TYPE IF EXISTS public.estados CASCADE;
DROP TYPE IF EXISTS public.tipo_usuario CASCADE;
DROP TYPE IF EXISTS public.em_ativo CASCADE;
DROP TYPE IF EXISTS public.status_motorista CASCADE;
DROP TYPE IF EXISTS public.plano CASCADE;
DROP TYPE IF EXISTS public.status_pev CASCADE;
DROP TYPE IF EXISTS public.status_solicitacao CASCADE;
DROP TYPE IF EXISTS public.patente CASCADE;

-- ------------------------------------------------------------
-- Tabelas
-- ------------------------------------------------------------
CREATE TABLE endereco (
    id_endereco  SERIAL       PRIMARY KEY,
    rua          VARCHAR(255) NOT NULL,
    cidade       VARCHAR(255) NOT NULL,
    bairro       VARCHAR(255) NOT NULL,
    cep          VARCHAR(8)   NOT NULL CHECK (cep ~ '^[0-9]{8}$'),
    numero       VARCHAR(10)  NOT NULL,
    complemento  VARCHAR(255),
    estado       CHAR(2)      NOT NULL CHECK (estado IN (
                     'AC','AL','AP','AM','BA','CE','DF','ES','GO','MA','MT','MS','MG','PA',
                     'PB','PR','PE','PI','RJ','RN','RS','RO','RR','SC','SP','SE','TO'))
);

CREATE TABLE usuario (
    id_usuario         SERIAL       PRIMARY KEY,
    email              VARCHAR(256) NOT NULL UNIQUE,
    telefone           VARCHAR(15)  NOT NULL CHECK (length(telefone) >= 10),
    nome               VARCHAR(255) NOT NULL,
    primeiro_registro  DATE         NOT NULL DEFAULT CURRENT_DATE,
    senha              VARCHAR(255) NOT NULL,   -- hash PBKDF2 (veja SenhaUtil.java)
    tipo_usuario       VARCHAR(3)   NOT NULL CHECK (tipo_usuario IN ('B2B','B2C','PEV')),
    id_endereco        INTEGER      NOT NULL REFERENCES endereco (id_endereco)
);

-- Administradores do painel (so entra no CRUD quem tem registro ATIVO aqui)
CREATE TABLE adm (
    id_adm    SERIAL       PRIMARY KEY,
    nome      VARCHAR(255) NOT NULL,
    email     VARCHAR(255) NOT NULL UNIQUE,
    senha     VARCHAR(255) NOT NULL,            -- hash PBKDF2 (veja SenhaUtil.java)
    em_ativo  VARCHAR(8)   NOT NULL DEFAULT 'Ativo' CHECK (em_ativo IN ('Ativo','Desativo'))
);

CREATE TABLE atualizacao (
    id_atualizacao  SERIAL       PRIMARY KEY,
    motivo          VARCHAR(255) NOT NULL,
    autorizacao     INTEGER      NOT NULL REFERENCES adm (id_adm),
    mudanca         VARCHAR(255) NOT NULL
);

CREATE TABLE motorista (
    id_motorista  SERIAL       PRIMARY KEY,
    status        VARCHAR(10)  NOT NULL DEFAULT 'Disponivel' CHECK (status IN ('Disponivel','Ocupado')),
    empresa_resp  VARCHAR(255) NOT NULL,
    telefone      VARCHAR(15)  NOT NULL CHECK (length(telefone) >= 10),
    nome          VARCHAR(255) NOT NULL,
    licenca       VARCHAR(50)  NOT NULL UNIQUE
);

CREATE TABLE b2b (
    id_b2b      SERIAL      PRIMARY KEY,
    cnpj        VARCHAR(14) NOT NULL UNIQUE CHECK (length(cnpj) = 14),
    plano       VARCHAR(12) NOT NULL DEFAULT 'Basico' CHECK (plano IN ('Empresa','Basico','Profissional')),
    id_usuario  INTEGER     NOT NULL UNIQUE REFERENCES usuario (id_usuario)
);

CREATE TABLE b2c (
    id_b2c      SERIAL      PRIMARY KEY,
    cpf         VARCHAR(11) NOT NULL UNIQUE CHECK (cpf ~ '^[0-9]{11}$'),
    id_usuario  INTEGER     NOT NULL UNIQUE REFERENCES usuario (id_usuario)
);

CREATE TABLE pev (
    id_pev        SERIAL      PRIMARY KEY,
    status        VARCHAR(8)  NOT NULL DEFAULT 'Pendente' CHECK (status IN ('Aprovada','Negado','Pendente')),
    dt_aprovacao  DATE        NOT NULL DEFAULT CURRENT_DATE,
    id_usuario    INTEGER     NOT NULL REFERENCES usuario (id_usuario)
);

CREATE TABLE solicitacao_coleta (
    id_solicitacao   SERIAL        PRIMARY KEY,
    status           VARCHAR(9)    NOT NULL DEFAULT 'Pendente' CHECK (status IN ('Realizada','Pendente','Cancelada')),
    volume_estimado  DECIMAL(10,2) NOT NULL CHECK (volume_estimado > 0),
    dt_solicitacao   DATE          NOT NULL DEFAULT CURRENT_DATE,
    id_b2b           INTEGER       NOT NULL REFERENCES b2b (id_b2b)
);

CREATE TABLE entrega_pev (
    id_entrega      SERIAL        PRIMARY KEY,
    dt_entrega      DATE          NOT NULL DEFAULT CURRENT_DATE,
    volume_entrega  DECIMAL(10,2) NOT NULL CHECK (volume_entrega > 0),
    id_pev          INTEGER       NOT NULL REFERENCES pev (id_pev),
    id_b2c          INTEGER       NOT NULL REFERENCES b2c (id_b2c)
);

CREATE TABLE coleta (
    id_coleta         SERIAL        PRIMARY KEY,
    dt_coleta         DATE          NOT NULL DEFAULT CURRENT_DATE,
    volume_coletado   DECIMAL(10,2) NOT NULL CHECK (volume_coletado > 0),
    avaliacao_coleta  INTEGER       NOT NULL CHECK (avaliacao_coleta BETWEEN 1 AND 5),
    id_solicitacao    INTEGER       NOT NULL REFERENCES solicitacao_coleta (id_solicitacao),
    id_motorista      INTEGER       NOT NULL REFERENCES motorista (id_motorista),
    id_b2b            INTEGER       NOT NULL REFERENCES b2b (id_b2b)
);

CREATE TABLE certificado (
    id_certificado  SERIAL        PRIMARY KEY,
    volume_total    DECIMAL(10,2) NOT NULL CHECK (volume_total >= 0),
    dt_emissao      DATE          NOT NULL DEFAULT CURRENT_DATE,
    pdf             VARCHAR(255)  NOT NULL,
    id_b2b          INTEGER       NOT NULL REFERENCES b2b (id_b2b),
    id_coleta       INTEGER       NOT NULL REFERENCES coleta (id_coleta)
);

-- Cada carteira pertence a um cliente (B2C) OU a uma empresa (B2B)
CREATE TABLE carteira (
    id_carteira   SERIAL      PRIMARY KEY,
    pontos_totais INTEGER     NOT NULL DEFAULT 0 CHECK (pontos_totais >= 0),
    patente       VARCHAR(6)  NOT NULL DEFAULT 'Bronze' CHECK (patente IN ('Ouro','Prata','Bronze')),
    nivel         INTEGER     NOT NULL DEFAULT 1 CHECK (nivel >= 1),
    id_b2c        INTEGER     UNIQUE REFERENCES b2c (id_b2c),
    id_b2b        INTEGER     UNIQUE REFERENCES b2b (id_b2b),
    CONSTRAINT chk_carteira_um_dono CHECK (num_nonnulls(id_b2c, id_b2b) = 1)
);

-- Cada movimentacao vem de uma coleta (empresa) OU de uma entrega (cliente)
CREATE TABLE movimentacao_pontos (
    id_movimentacao    SERIAL   PRIMARY KEY,
    quantidade_pontos  INTEGER  NOT NULL,
    id_carteira        INTEGER  NOT NULL REFERENCES carteira (id_carteira),
    id_coleta          INTEGER  REFERENCES coleta (id_coleta),
    id_entrega         INTEGER  REFERENCES entrega_pev (id_entrega),
    CONSTRAINT chk_movimentacao_uma_origem CHECK (num_nonnulls(id_coleta, id_entrega) = 1)
);

COMMIT;
