-- ============================================================
-- BANCO DE DADOS OLIUS - PostgreSQL
-- Script 02: CARGA INICIAL (DataLoad) para testes e demonstracao
--
-- Rode DEPOIS do 01_esquema.sql, no mesmo banco.
-- Os ids das chaves estrangeiras dependem da ordem dos INSERTs
-- (as tabelas acabaram de ser criadas, entao os ids comecam em 1).
-- ============================================================

BEGIN;

-- ------------------------------------------------------------
-- ENDERECO (12): 1-2, 5-7 clientes | 3-4, 11-12 empresas | 8-10 pontos de entrega
-- ------------------------------------------------------------
INSERT INTO endereco (rua, cidade, bairro, cep, numero, complemento, estado) VALUES
('Rua Augusta',              'Sao Paulo',      'Consolacao',       '01304001', '1200', 'Sala 31',  'SP'),
('Avenida Paulista',         'Sao Paulo',      'Bela Vista',       '01310100', '1578', NULL,       'SP'),
('Rua das Flores',           'Campinas',       'Centro',           '13010010', '45',   'Apto 12',  'SP'),
('Avenida Atlantica',        'Rio de Janeiro', 'Copacabana',       '22010000', '900',  NULL,       'RJ'),
('Rua da Bahia',             'Belo Horizonte', 'Lourdes',          '30160011', '300',  'Bloco B',  'MG'),
('Rua XV de Novembro',       'Curitiba',       'Centro',           '80020310', '210',  NULL,       'PR'),
('Avenida Beira Mar',        'Florianopolis',  'Centro',           '88010400', '77',   'Casa 2',   'SC'),
('Rua Sete de Setembro',     'Porto Alegre',   'Centro Historico', '90010190', '150',  NULL,       'RS'),
('Avenida Sete de Setembro', 'Salvador',       'Vitoria',          '40080002', '480',  'Sala 5',   'BA'),
('Rua do Sol',               'Recife',         'Boa Viagem',       '51021000', '62',   NULL,       'PE'),
('Rua Industrial',           'Guarulhos',      'Cumbica',          '07220000', '1000', 'Galpao 4', 'SP'),
('Avenida dos Autonomistas', 'Osasco',         'Centro',           '06194000', '2500', 'Galpao 1', 'SP');

-- ------------------------------------------------------------
-- USUARIO (12): 1-4 B2B | 5-9 B2C | 10-12 PEV
-- Todas as senhas de teste = senha_teste_123 (guardadas como hash PBKDF2)
-- ------------------------------------------------------------
INSERT INTO usuario (email, telefone, nome, primeiro_registro, senha, tipo_usuario, id_endereco) VALUES
('contato@ecoindustria.com.br',  '11987650001', 'Eco Industria Ltda',    '2025-01-10', 'pbkdf2$120000$UQxZNybHouR90ZSS3IWAQA==$nbhDZkd7zlVmU7lHjN/Rp4hAfoeEIZH5C5Ru6dl6Q+c=', 'B2B', 11),
('compras@supermercadovida.com', '11987650002', 'Supermercado Vida',     '2025-02-14', 'pbkdf2$120000$UQxZNybHouR90ZSS3IWAQA==$nbhDZkd7zlVmU7lHjN/Rp4hAfoeEIZH5C5Ru6dl6Q+c=', 'B2B', 12),
('adm@restaurantesabor.com.br',  '19987650003', 'Restaurante Sabor Bom', '2025-03-05', 'pbkdf2$120000$UQxZNybHouR90ZSS3IWAQA==$nbhDZkd7zlVmU7lHjN/Rp4hAfoeEIZH5C5Ru6dl6Q+c=', 'B2B', 3),
('oleo@lanchonetecentral.com',   '21987650004', 'Lanchonete Central',    '2025-04-20', 'pbkdf2$120000$UQxZNybHouR90ZSS3IWAQA==$nbhDZkd7zlVmU7lHjN/Rp4hAfoeEIZH5C5Ru6dl6Q+c=', 'B2B', 4),
('ana.souza@email.com',          '11987650005', 'Ana Souza',             '2025-05-11', 'pbkdf2$120000$UQxZNybHouR90ZSS3IWAQA==$nbhDZkd7zlVmU7lHjN/Rp4hAfoeEIZH5C5Ru6dl6Q+c=', 'B2C', 1),
('bruno.lima@email.com',         '11987650006', 'Bruno Lima',            '2025-06-02', 'pbkdf2$120000$UQxZNybHouR90ZSS3IWAQA==$nbhDZkd7zlVmU7lHjN/Rp4hAfoeEIZH5C5Ru6dl6Q+c=', 'B2C', 2),
('carla.dias@email.com',         '31987650007', 'Carla Dias',            '2025-06-18', 'pbkdf2$120000$UQxZNybHouR90ZSS3IWAQA==$nbhDZkd7zlVmU7lHjN/Rp4hAfoeEIZH5C5Ru6dl6Q+c=', 'B2C', 5),
('diego.alves@email.com',        '41987650008', 'Diego Alves',           '2025-07-09', 'pbkdf2$120000$UQxZNybHouR90ZSS3IWAQA==$nbhDZkd7zlVmU7lHjN/Rp4hAfoeEIZH5C5Ru6dl6Q+c=', 'B2C', 6),
('elisa.matos@email.com',        '48987650009', 'Elisa Matos',           '2025-08-01', 'pbkdf2$120000$UQxZNybHouR90ZSS3IWAQA==$nbhDZkd7zlVmU7lHjN/Rp4hAfoeEIZH5C5Ru6dl6Q+c=', 'B2C', 7),
('fabio.rocha@email.com',        '51987650010', 'Fabio Rocha',           '2025-08-25', 'pbkdf2$120000$UQxZNybHouR90ZSS3IWAQA==$nbhDZkd7zlVmU7lHjN/Rp4hAfoeEIZH5C5Ru6dl6Q+c=', 'PEV', 8),
('gabriela.nunes@email.com',     '71987650011', 'Gabriela Nunes',        '2025-09-03', 'pbkdf2$120000$UQxZNybHouR90ZSS3IWAQA==$nbhDZkd7zlVmU7lHjN/Rp4hAfoeEIZH5C5Ru6dl6Q+c=', 'PEV', 9),
('henrique.paes@email.com',      '81987650012', 'Henrique Paes',         '2025-09-20', 'pbkdf2$120000$UQxZNybHouR90ZSS3IWAQA==$nbhDZkd7zlVmU7lHjN/Rp4hAfoeEIZH5C5Ru6dl6Q+c=', 'PEV', 10);

-- ------------------------------------------------------------
-- ADM: administradores que podem entrar no painel (CRUD)
--   Login de teste:  admin@olius.local  /  senha_teste_123
--   O segundo esta DESATIVADO, para demonstrar que nao consegue entrar.
-- Para criar outro administrador gere o hash com SenhaUtil.java (veja o README).
-- ------------------------------------------------------------
INSERT INTO adm (nome, email, senha, em_ativo) VALUES
('Administrador Olius', 'admin@olius.local',         'pbkdf2$120000$UQxZNybHouR90ZSS3IWAQA==$nbhDZkd7zlVmU7lHjN/Rp4hAfoeEIZH5C5Ru6dl6Q+c=', 'Ativo'),
('Administrador Inativo', 'inativo@olius.local',     'pbkdf2$120000$UQxZNybHouR90ZSS3IWAQA==$nbhDZkd7zlVmU7lHjN/Rp4hAfoeEIZH5C5Ru6dl6Q+c=', 'Desativo');

INSERT INTO atualizacao (motivo, autorizacao, mudanca) VALUES
('Carga inicial do sistema',                1, 'Cadastro dos dados de teste'),
('Correcao de telefone de motorista',       1, 'Telefone do motorista 2 atualizado');

INSERT INTO motorista (status, empresa_resp, telefone, nome, licenca) VALUES
('Disponivel', 'TransVerde Logistica', '11999110001', 'Carlos Henrique',  'CNH-AD-00123456'),
('Ocupado',    'TransVerde Logistica', '11999110002', 'Paulo Ricardo',    'CNH-AD-00123457'),
('Disponivel', 'EcoFrota Transportes', '19999110003', 'Marcia Fernandes', 'CNH-AE-00234567'),
('Disponivel', 'EcoFrota Transportes', '21999110004', 'Joao Batista',     'CNH-AD-00345678');

INSERT INTO b2b (cnpj, plano, id_usuario) VALUES
('11222333000181', 'Profissional', 1),
('22333444000172', 'Empresa',      2),
('33444555000163', 'Basico',       3),
('44555666000154', 'Basico',       4);

INSERT INTO b2c (cpf, id_usuario) VALUES
('11122233344', 5),
('22233344455', 6),
('33344455566', 7),
('44455566677', 8),
('55566677788', 9);

-- PEV: pontos de entrega operados pelos usuarios do tipo PEV (10, 11 e 12)
INSERT INTO pev (status, dt_aprovacao, id_usuario) VALUES
('Aprovada', '2025-09-01', 10),
('Aprovada', '2025-09-15', 11),
('Pendente', '2025-10-05', 12),
('Negado',   '2025-10-12', 12);

INSERT INTO solicitacao_coleta (status, volume_estimado, dt_solicitacao, id_b2b) VALUES
('Realizada', 200.00, '2025-10-01', 1),
('Realizada', 150.50, '2025-10-03', 2),
('Realizada',  80.00, '2025-10-08', 3),
('Pendente',  120.00, '2025-10-20', 4),
('Cancelada',  60.00, '2025-10-22', 1),
('Realizada', 300.00, '2025-11-02', 1);

INSERT INTO entrega_pev (dt_entrega, volume_entrega, id_pev, id_b2c) VALUES
('2025-10-02',  5.00, 1, 1),
('2025-10-04',  3.50, 1, 2),
('2025-10-06',  8.00, 2, 3),
('2025-10-09',  2.25, 2, 4),
('2025-10-11', 10.00, 1, 5),
('2025-10-15',  4.75, 2, 1);

INSERT INTO coleta (dt_coleta, volume_coletado, avaliacao_coleta, id_solicitacao, id_motorista, id_b2b) VALUES
('2025-10-02', 195.00, 5, 1, 1, 1),
('2025-10-04', 150.50, 4, 2, 3, 2),
('2025-10-09',  78.00, 5, 3, 4, 3),
('2025-11-03', 298.00, 4, 6, 2, 1);

INSERT INTO certificado (volume_total, dt_emissao, pdf, id_b2b, id_coleta) VALUES
(195.00, '2025-10-03', 'certificados/cert_0001.pdf', 1, 1),
(150.50, '2025-10-05', 'certificados/cert_0002.pdf', 2, 2),
( 78.00, '2025-10-10', 'certificados/cert_0003.pdf', 3, 3),
(298.00, '2025-11-04', 'certificados/cert_0004.pdf', 1, 4);

-- CARTEIRA: 1-5 clientes (B2C) | 6-9 empresas (B2B)
INSERT INTO carteira (pontos_totais, patente, nivel, id_b2c, id_b2b) VALUES
( 98, 'Bronze', 1, 1,    NULL),
( 35, 'Bronze', 1, 2,    NULL),
( 80, 'Prata',  2, 3,    NULL),
( 22, 'Bronze', 1, 4,    NULL),
(100, 'Prata',  2, 5,    NULL),
(493, 'Ouro',   4, NULL, 1),
(150, 'Prata',  2, NULL, 2),
( 78, 'Bronze', 1, NULL, 3),
(  0, 'Bronze', 1, NULL, 4);

INSERT INTO movimentacao_pontos (quantidade_pontos, id_carteira, id_coleta, id_entrega) VALUES
( 50, 1, NULL, 1),
( 35, 2, NULL, 2),
( 80, 3, NULL, 3),
( 22, 4, NULL, 4),
(100, 5, NULL, 5),
( 48, 1, NULL, 6),
(195, 6, 1,    NULL),
(150, 7, 2,    NULL),
( 78, 8, 3,    NULL),
(298, 6, 4,    NULL);

COMMIT;
